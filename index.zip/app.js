'use strict';

const switcher = document.querySelector('.btn');

switcher.addEventListener('click', function() {
    document.body.classList.toggle('dark-theme');

    var className = document.body.className;
    if (className === "light-theme") {
        this.textContent = "Dark";
        document.body.style.backgroundColor = "black"; // Altera a cor de fundo para preto
    } else {
        this.textContent = "Light";
        document.body.style.backgroundColor = "var(--bg)"; // Restaura a cor de fundo definida pelo tema
    }

    console.log('current class name: ' + className);
});